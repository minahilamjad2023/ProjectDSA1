#include "header.h"
#include <sstream>

Command::Command()
{ }

Command::Command(const string& command)
{ }

// Function to trim both leading and trailing whitespaces
string Command::trim(string& strToTrim) 
{
    // Define the characters that are considered as whitespace
    const std::string whitespace = " \t\n\r\f\v";

    // Find the first non-whitespace character from the start of the string
    size_t start = strToTrim.find_first_not_of(whitespace);
    if (start == std::string::npos) 
    { 
        return ""; // All whitespaces
    }

    // Find the last non-whitespace character from the end of the string
    size_t end = strToTrim.find_last_not_of(whitespace);

    // Return the substring that is trimmed
    return strToTrim.substr(start, end - start + 1);
}

bool Command::validateCommand(string& command, const StockPile& s, const WastePile& w, const FoundationPile& f, const Tableau& t)
{
    command = trim(command);
    // Parsing string and checking thats its valid or not
    stringstream ss(command);
    string move, source, destination, numberOfCards;

    getline(ss, move, ' ');
    getline(ss, source, ',');
    getline(ss, destination, ',');
    getline(ss, numberOfCards, ',');

    move = trim(move);
    source = trim(source);
    destination = trim(destination);
    numberOfCards = trim(numberOfCards);

    if (move == "m")
    {
        if (source == "s")
        {
            // Condition to check "m s, w, 1"
            if (destination == "w" && numberOfCards == "1")
            {
                if(s.size() == 0)
                {
                    wcout << "Error: Stock Pile is empty cannot move card from it to Waste Pile" << endl;
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                wcout << "Error: Can only move 1 card at a time from Stock Pile to only Waste Pile." << endl;
                return false;
            }
        }
        else if (source == "w")
        {
            if ((destination == "f1" || destination == "f2" || destination == "f3" || destination == "f4") && numberOfCards == "1")
            {
                if(w.size() == 0)
                {
                    wcout << "Error: Waste Pile is empty cannot move card from it to Foundation Pile" << endl;
                    return false;
                }
                else // Checking required type of waste pile's top card with type of foundation pile(do their suits match) and checking the asceding order of rank of w.p card
                {
                    if(!f.checkCard(destination[1] - '1', w.peek()))
                    {
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
            }
            else if ((destination == "c1" || destination == "c2" || destination == "c3" || destination == "c4" || destination == "c5" || destination == "c6" || destination == "c7") && numberOfCards == "1")
            {
                if(w.size() == 0)
                {
                    wcout << "Error: Waste Pile is empty cannot move card from it to Tableau" << endl;
                    return false;
                }
                else // Checking suit of card with the suit of required tableau column and also checking the descending order
                {
                    if(!t.checkCard(destination[1] - '1', w.peek()))
                    {
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
            }
            else if (destination == "s" && stoi(numberOfCards) > 0)
            {
                if(w.size() == 0 || s.size() != 0)
                {
                    wcout << "Error: Waste Pile is either empty or Stock Pile is not empty. Cannot move from Waste Pile to Stock Pile" << endl;
                    return false;
                }
                else if(stoi(numberOfCards) != w.size())
                {
                    wcout << "Error: Can only move all cards from Waste Pile to Stock Pile not one by one" << endl;
                    return false;                   
                }
                else
                {
                    return true;
                }
            }
            else
            {
                wcout << "Error: Can only move 1 card from Waste Pile to Foundation or Tableau, or all cards to Stock pile." << endl;
                return false;
            }
        }
        else if (source == "f1"|| source == "f2"|| source == "f3"|| source == "f4")
        {
            if ((destination == "c1" || destination == "c2" || destination == "c3" || destination == "c4" || destination == "c5" || destination == "c6" || destination == "c7") && numberOfCards == "1")
            {
                if(!f.checkSize(source[1] - '1')) // Checking that required source foundation pile contains cards or not
                {
                    wcout << "Error: The specified Foundaiton Pile is empty cannot move from Foundation Pile to Tableau" << endl;
                    return false;
                }
                else // Checking the descending order and alternating color for tableau
                {
                    if(!t.checkCard(destination[1] - '1', f.peek(source[1] - '1')))
                    {
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
            }
            else
            {
                wcout << "Error: Can only move 1 card from Foundation Pile to a Tableau Column." << endl;
                return false;
            }
        }
        else if ((source == "c1" || source == "c2" || source == "c3" || source == "c4" || source == "c5" || source == "c6" || source == "c7"))
        {
            if ((destination == "c1" || destination == "c2" || destination == "c3" || destination == "c4" || destination == "c5" || destination == "c6" || destination == "c7") && stoi(numberOfCards) > 0)
            {
                if(!t.checkCardWithin(source[1] - '1', destination[1] - '1', stoi(numberOfCards)))
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else if ((destination == "f1" || destination == "f2" || destination == "f3" || destination == "f4") && numberOfCards == "1")
            {
                // Checking that can foundation pile take the card or not
                if(!f.checkCard(destination[1] - '1', t.peek(source[1] - '1')))
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                wcout << "Error: Can only move cards from Tableau to within Tableau or to Foundation Pile(only one)." << endl;
                return false;
            }
        }
        else
        {
            wcout << "Error: Invalid source specified." << endl;
            return false;
        }
    }
    else
    {
        wcout << "Error: Invalid move command, only 'm' is allowed." << endl;
        return false;
    }
}

void Command::push(const string& str) 
{
    commandsStack.push(str);
}

void Command::implementCommand(string& command, StockPile& s, WastePile& w, FoundationPile& f, Tableau& t, bool reverse)
{
    if(!reverse)
    {
        if(!validateCommand(command, s, w, f, t))
            return;
            
        command = trim(command);

        // Parsing string and checking thats its valid or not
        stringstream ss(command);
        string move, source, destination, numberOfCards;

        getline(ss, move, ' ');
        getline(ss, source, ',');
        getline(ss, destination, ',');
        getline(ss, numberOfCards, ',');

        move = trim(move);
        source = trim(source);
        destination = trim(destination);
        numberOfCards = trim(numberOfCards);

        if(source == "s")
        {
            w.push(s.pop());
        }
        else if (source == "w")
        {
            if (destination == "f1" || destination == "f2" || destination == "f3" || destination == "f4") 
            {
                f.push(destination[1] - '1', w.pop());
            }
            else if (destination == "c1" || destination == "c2" || destination == "c3" || destination == "c4" || destination == "c5" || destination == "c6" || destination == "c7")
            {
                t.push(destination[1] - '1', w.pop());
            }
            else
            {
                while(!w.isEmpty())
                {
                    s.push(w.pop());
                }
            }
        }
        else if (source == "f1"|| source == "f2"|| source == "f3"|| source == "f4")
        {
            if (destination == "c1" || destination == "c2" || destination == "c3" || destination == "c4" || destination == "c5" || destination == "c6" || destination == "c7")
            {
                t.push(destination[1] - '1', f.pop(source[1] - '1'));
            }
        }
        else if ((source == "c1" || source == "c2" || source == "c3" || source == "c4" || source == "c5" || source == "c6" || source == "c7"))
        {
            if (destination == "c1" || destination == "c2" || destination == "c3" || destination == "c4" || destination == "c5" || destination == "c6" || destination == "c7")
            {
                t.moveCardsWithinTableau(source[1] - '1', destination[1] - '1', stoi(numberOfCards));
            }
            else
            {
                f.push(destination[1] - '1', t.pop(source[1] - '1'));
            }
        }
    }
    else
    {
        string lastCommand = commandsStack.top();
        commandsStack.pop();

        // Parsing string and checking thats its valid or not
        stringstream ss(lastCommand);
        string move, source, destination, numberOfCards;

        getline(ss, move, ' ');
        getline(ss, source, ',');
        getline(ss, destination, ',');
        getline(ss, numberOfCards, ',');

        move = trim(move);
        source = trim(source);
        destination = trim(destination);
        numberOfCards = trim(numberOfCards);

        if(source == "s")
        {
            s.push(w.pop());
        }
        else if(source == "w")
        {
            if (destination == "c1" || destination == "c2" || destination == "c3" || destination == "c4" || destination == "c5" || destination == "c6" || destination == "c7")
            {
                w.push(t.pop(destination[1] - '1'));
            }
            else if (destination == "f1" || destination == "f2" || destination == "f3" || destination == "f4") 
            {
                w.push(f.pop(destination[1] - '1'));
            }
            else
            {
                while(!s.isEmpty())
                {
                    w.push(s.pop());
                }
            }
        }
        else if (source == "f1" || source == "f2" || source == "f3" || source == "f4")
        {
            f.push(source[1] - '1', t.pop(destination[1] - '1'));
        }
        else if ((source == "c1" || source == "c2" || source == "c3" || source == "c4" || source == "c5" || source == "c6" || source == "c7"))
        {
            if (destination == "c1" || destination == "c2" || destination == "c3" || destination == "c4" || destination == "c5" || destination == "c6" || destination == "c7")
            {
                t.moveCardsWithinTableau(destination[1] - '1', source[1] - '1', stoi(numberOfCards));
            }
            else
            {
                t.push(source[1] - '1', f.pop(destination[1] - '1'));
            }
        }
    }        
}
