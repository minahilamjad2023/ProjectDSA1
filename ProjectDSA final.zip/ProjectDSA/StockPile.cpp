#include "header.h"

StockPile::StockPile() : stockPileStack(Stack()), cardsGivenToTableau(false)
{ }

// Move Constructor For StockPile class
StockPile::StockPile(StockPile&& other) noexcept : stockPileStack(Stack(move(other.stockPileStack))), cardsGivenToTableau(other.cardsGivenToTableau)
{ 
    other.cardsGivenToTableau = false;
}

// Move assignment Operator for StockPile class
StockPile& StockPile::operator = (StockPile&& other) noexcept
{
    stockPileStack = (move(other.stockPileStack)); // Although other is already rvalue ref but error occurs because the compiler takes ever thigns as const ref in context of constructor by default so we have to redundantly also mention it
    cardsGivenToTableau = other.cardsGivenToTableau;
    other.cardsGivenToTableau = false;  // Clear state of other
    return *this;
}

// Move Constructor for WastePile class
StockPile::StockPile(WastePile&& other) noexcept : stockPileStack(move(other.wastePileStack)), cardsGivenToTableau(false)
{ }

// Move Assignment operator for WastePile class
StockPile& StockPile::operator = (WastePile&& other) noexcept
{
    stockPileStack = move(other.wastePileStack);
    cardsGivenToTableau = true;
    return *this;
}

void StockPile::distributeCards(Tableau& t)
{
    cardsGivenToTableau = true;
    
    // Initializing 52 cards in stock and shuffling them
    stockPileStack.initializeStack();
    stockPileStack.shuffleStack();

    // making two pointers one that move forward and other that move downward
    Tableau::TableauCard* forward = t.tableauHead;
    Tableau::TableauCard* downward = t.tableauHead;

    for(int i = 1; i <= No_OF_COLUMNS; i++)
    {
        for(int j = 1; j <= i; j++)
        {
            forward->noOfCards = j;
            forward->noOfVisibleCards = 1;
            Tableau::TableauCard* newCard = new Tableau::TableauCard(move(stockPileStack.pop()));
            downward->down = newCard;
            newCard->up = downward;
            downward = downward->down;
        }
        forward = forward->next();
        downward = forward;
    }

}

Card StockPile::pop()
{
    if(!stockPileStack.isEmpty())
        return stockPileStack.pop();
    else
        throw runtime_error("Cannot pop from an empty stock pile");
}

void StockPile::push(Card&& other)
{
    stockPileStack.push(move(other));
}

int StockPile::size() const
{
    return stockPileStack.size();
}

wstring StockPile::peek() const
{
    if(!stockPileStack.isEmpty())
        return stockPileStack.peek();
    else
        throw runtime_error("Cannot peek on a Empty Stock Pile");
}

bool StockPile::isEmpty() const
{
    return stockPileStack.isEmpty();
}