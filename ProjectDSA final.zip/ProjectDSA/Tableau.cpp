#include "header.h"
#include <sstream>

static std::wstring numToWString(int num) {
    std::wstringstream wss;
    wss << num;
    return wss.str();
}

// Parametrized Constructor
Tableau::TableauCard::TableauCard(int noOfCards, int noOfVisibleCards, const wstring& rank, const wstring& suit, Card* next, Card* prev) 
: Card(rank, suit, next, prev), noOfCards(noOfCards), noOfVisibleCards(noOfVisibleCards), up(nullptr), down(nullptr)
{ }

// Move Constructor
Tableau::TableauCard::TableauCard(TableauCard&& other) noexcept : Card(move(other)),  noOfCards(other.noOfCards), noOfVisibleCards(other.noOfVisibleCards), up(other.up), down(other.down)
{
    other.up = nullptr;
    other.down = nullptr;
    other.noOfCards = 0;
    other.noOfVisibleCards = 0;
}

// Move Assignemnent
Tableau::TableauCard& Tableau::TableauCard::operator = (TableauCard&& other) noexcept
{
    if(this != & other)
    {
        Card::operator = (move(other)); // Move the base class part
        noOfCards = other.noOfCards;
        noOfVisibleCards = other.noOfVisibleCards;
        up = nullptr;
        down = nullptr;
        other.down = nullptr;
        other.up = nullptr;
        other.noOfCards = 0;
        other.noOfVisibleCards = 0;
    }
    return *this;
}

// Move constructor to change Card to TableauCard
Tableau::TableauCard::TableauCard(Card&& other) noexcept : Card(move(other)),  noOfCards(0), noOfVisibleCards(0), up(nullptr), down(nullptr)
{ }

// Get card representation
wstring Tableau::TableauCard::getCard() const {
    return Card::getCard(); // Use the base class method to get the card string representation
}

// Returning references of Card* as TableauCard*&
Tableau::TableauCard*& Tableau::TableauCard::next()
{
    return reinterpret_cast<TableauCard*&>(Card::next);
}

// Returning references of Card* as TableauCard*&
Tableau::TableauCard*& Tableau::TableauCard::prev() 
{
    return reinterpret_cast<TableauCard*&>(Card::prev);
}

/*
------------------------------------------------Implementing Tablueau class------------------------------------------------------
*/

// Default Constructor that initialized the Tableau Dummy Cards
Tableau::Tableau()
{
    // Creating 7 dummy nodes under which the cards are being placed in tableau columns
    tableauHead = new TableauCard(0, 0);
    TableauCard* current = tableauHead;
    for(int i = 1; i < No_OF_COLUMNS; i++)
    {
        TableauCard* dummyCard = new TableauCard(0, 0);
        current->next() = dummyCard;
        dummyCard->prev() = current;
        current = dummyCard;
    }
    tableauTail = current;
}

// Pushing Cards on specific destination
void Tableau::push(const int destination, Card&& card)
{
    if(destination >= 0 && destination <= 6)
    {
        TableauCard* forward = tableauHead;

        for(int i = 0; i < destination; i++)
        {
            forward = forward->next();
        }
        TableauCard* downward = forward;

        while(downward->down != nullptr)
            downward = downward->down;
        
        TableauCard* newCard = new TableauCard(move(card));
        downward->down = newCard;
        newCard->up = downward;
        forward->noOfCards++;
        forward->noOfVisibleCards++;
    }
    else
        throw runtime_error("Tableau::push:The desitnation column no of the Tableau is out of range while insertion from WP or FP");
}

// Poping cards from specific source
Card Tableau::pop(const int source)
{
    if(source >= 0 && source <= 6)
    {
        TableauCard* forward = tableauHead;

        for(int i = 0; i < source; i++)
        {
            forward = forward->next();
        }
        TableauCard* downward = forward;
        TableauCard* prevDownward = nullptr;

        while(downward->down != nullptr)
        {
            prevDownward = downward;
            downward = downward->down;
        }
        
        if(downward == forward && prevDownward == nullptr) // Means that downward is pointing to the dummy node and prevDownward == nullptr and so we cannot pop it
            throw runtime_error("Tableau::pop: Column specified does not contain cards so cannot be poped");
        else
        {
            forward->noOfCards--;

            // When we have noOfVisibleCards = 1 then it remains 1 if there is atleast one card left in col
            if(prevDownward == forward) // Which means that the only card is deleted
                forward->noOfVisibleCards = 0;
            else if(forward->noOfVisibleCards > 1) // If the column has multiple face-up cards, popping the top card simply reduces the number of face-up cards but doesn't reveal any new cards.
                forward->noOfVisibleCards--;

            Card temp = Card(move(*downward));
            prevDownward->down = nullptr;
            delete downward;
            return temp;
        }
    }
    else
        throw runtime_error("Tableau::pop: Index out of bound");    
}

// Peeking Card from specific source
wstring Tableau::peek(const int source) const
{
    if(source >= 0 && source <= 6)
    {
        TableauCard* forward = tableauHead;
        for(int i = 0; i < source; i++)
            forward = forward->next();

        TableauCard* downward = forward;
        while(downward->down != nullptr)
            downward = downward->down;

        if(downward == forward)
            return L"";
        else
            return downward->getCard();
    }
    else
        throw runtime_error("Tableau::peek: Index is out of bound");
}

// Getting size from specific source
int Tableau::size(const int source) const
{
    if(source >= 0 && source <= 6)
    {
        TableauCard* forward = tableauHead;
        for(int i = 0; i < source; i++)
            forward = forward->next();
        
        return forward->noOfCards;
    }
    else
        throw runtime_error("Tableau::size: Index out of bound");
}

// Moving Cards within Tableau Columns
void Tableau::moveCardsWithinTableau(const int sourceIndex, const int destinationIndex, const int cardsToMove)
{
    if((sourceIndex >= 0 && sourceIndex <= 6) && (destinationIndex >= 0 && destinationIndex <= 6))
    {
        TableauCard* sourceCol = tableauHead;
        TableauCard* destinationCol = tableauHead;
        
        // Move to respective columns in tableau
        for (int i = 0; i < max(sourceIndex, destinationIndex); i++)
        {
            if (i < sourceIndex)
                sourceCol = sourceCol->next();
            if (i < destinationIndex)
                destinationCol = destinationCol->next();
        }

        // Traverse to the bottom of the destination column to find the last card
        TableauCard* destinationColCard = destinationCol;
        while (destinationColCard->down != nullptr)
            destinationColCard = destinationColCard->down;

        // Traverse to the card that will be moved from the source column
        TableauCard* prevSourceColCard = nullptr;
        TableauCard* sourceColCard = sourceCol;
        for (int i = 0; i < sourceCol->noOfCards - cardsToMove + 1; i++)
        {
            prevSourceColCard = sourceColCard;
            sourceColCard = sourceColCard->down;
        }

        if(prevSourceColCard == nullptr)
        {
            wcout << "Error: The source card cannot be moved as the source col is empty" << endl;
            return;
        }

        prevSourceColCard->down = nullptr;
        destinationColCard->down = sourceColCard;
        sourceColCard->up = destinationColCard;

        // Reset the no of total cards in tableau columns
        sourceCol->noOfCards -= cardsToMove;
        destinationCol->noOfCards += cardsToMove;

        // Reset the visible cards in the tablesu source column as well as destination column
        if(cardsToMove == sourceCol->noOfVisibleCards)
        {
            if(sourceCol->down != nullptr)
                sourceCol->noOfVisibleCards = 1;
            else
                sourceCol->noOfVisibleCards = 0;
        }
        else
        {
            sourceCol->noOfVisibleCards = sourceCol->noOfVisibleCards - cardsToMove;
        }
        destinationCol->noOfVisibleCards += cardsToMove;
    }
    else
        throw runtime_error("Tableau::moveCardsWithinTableau: Index out of bound");
}

// Checking that a Card can be moved from Foundation Pile or Waste Pile To Tableau or not
bool Tableau::checkCard(const int destination, wstring card) const
{
    // Split the card into rank and suit based on space
    size_t spacePos = card.find(' ');
    wstring rankCard = card.substr(0, spacePos);
    wstring suitCard = card.substr(spacePos + 1);

    // Ensure destination is within bounds (Tableau has columns 1-7)
    if (destination < 0 || destination > 6) 
    {
        cerr << "Error: Invalid Tableau column number." << endl;
        return false;
    }

    // Traverse to the correct column in the tableau
    TableauCard* forward = tableauHead;
    for (int i = 0; i < destination; i++)
        forward = forward->next();

    // Go to the bottom card in the selected column
    TableauCard* downward = forward;
    while (downward->down != nullptr)
        downward = downward->down;
    
    // If the column is empty, only a King can be placed
    if (downward == forward)
    {
        if (rankCard == ranks[12]) // King is the last rank (index 12)
            return true;
        else
        {
            wcout << "Error: As the column is empty, only a King can be placed." << endl;
            return false;
        }
    }

    // Check for alternating colors (red-black or black-red)
    bool isCurrentCardRed = (suitCard == suits[0] || suitCard == suits[1]); // Hearts or Diamonds
    bool isDownwardCardRed = (downward->suit == suits[0] || downward->suit == suits[1]);

    if (isCurrentCardRed == isDownwardCardRed)
    {
        wcout << "Error: The cards should alternate in color (red-black or black-red)." << endl;
        return false;
    }

    // Check for descending order by comparing ranks
    int downwardRankIndex = 12; // Start with the highest rank (King)
    while (downwardRankIndex >= 0 && ranks[downwardRankIndex] != downward->rank)
        downwardRankIndex--;
    
    if (downwardRankIndex > 0)
    {
        if (rankCard == ranks[downwardRankIndex - 1]) // The next rank should be one lower
            return true;
        else
        {
            wcout << L"Error: The " << card << L" does not obey descending order when inserted in " << L"c" << numToWString(destination + 1) << L"." 
                  << L"The next card can onyl be: " << ranks[downwardRankIndex - 1] << L" " 
                  << ((suitCard == suits[2] || suitCard == suits[3]) ? suits[0] : suits[2])
                  << L" or " << ranks[downwardRankIndex - 1] << L" " 
                  << ((suitCard == suits[2] || suitCard == suits[3]) ? suits[1] : suits[3]) << endl;
            return false;
        }
    }
    else
    {
        wcout << "Error: No card can be placed under an Ace (the lowest rank)." << endl;
        return false;
    }
}

// Checking that a cards can be moved within Columns of Tableau or not
bool Tableau::checkCardWithin(const int sourceIndex, const int destinationIndex, const int cardsToMove) const
{
    // Validate source and destination indices are within valid tableau range (0-6)
    if ((sourceIndex < 0 || sourceIndex > 6) || (destinationIndex < 0 || destinationIndex > 6))
        throw std::runtime_error("Tableau::checkCardWithin: Index out of Bound");

    // Ensure the source and destination columns are not the same
    if (sourceIndex == destinationIndex)
    {
        wcout << "Error: The source and destination cannot be the same" << endl;
        return false;
    }

    // Checking the size of the source column
    if (size(sourceIndex) == 0)
    {
        wcout << "Error: The source column is empty so cannot move cards from it " << endl;
        return false;
    }

    // Initialize source and destination column pointers
    TableauCard* sourceCol = tableauHead;
    TableauCard* destinationCol = tableauHead;

    // Traverse to the appropriate source and destination columns
    for (int i = 0; i < max(sourceIndex, destinationIndex); i++)
    {
        if (i < sourceIndex) 
            sourceCol = sourceCol->next();
        if (i < destinationIndex) 
            destinationCol = destinationCol->next();
    }

    // Check if the number of visible cards in the source column is sufficient for the move
    if (sourceCol->noOfVisibleCards < cardsToMove)
    {
        wcout << "Error: More cards are being moved than are visible in the source column" << endl;
        return false;
    }

    // Traverse to the bottom of the destination column to find the last card
    TableauCard* destinationColCard = destinationCol;
    while (destinationColCard->down != nullptr)
        destinationColCard = destinationColCard->down;

    // Traverse to the card that will be moved from the source column
    TableauCard* sourceColCard = sourceCol;
    for (int i = 0; i < sourceCol->noOfCards - cardsToMove + 1; i++)
        sourceColCard = sourceColCard->down;

    // Case 1: If destination column is empty, only a King can be placed
    if (destinationColCard == destinationCol)
    {
        if (sourceColCard->rank == ranks[12]) // King is the highest rank
            return true;
        else
        {
            wcout << "Error: Only a King can be moved to an empty column" << endl;
            return false;
        }
    }
    else
    {
        // Case 2: Non-empty destination column, check for valid alternating color and descending rank

        // Check if source and destination cards alternate in color
        bool isSourceCardRed = (sourceColCard->suit == suits[0] || sourceColCard->suit == suits[1]); // Hearts/Diamonds
        bool isDestinationCardRed = (destinationColCard->suit == suits[0] || destinationColCard->suit == suits[1]);

        if (isSourceCardRed == isDestinationCardRed)
        {
            wcout << "Error: Cards must alternate in color (red-black or black-red)" << endl;
            return false;
        }

        // Check if source card is exactly one rank lower than the destination card
        int destinationRankIndex = 12; // Start from the highest rank (King)
        while (destinationRankIndex >= 0 && ranks[destinationRankIndex] != destinationColCard->rank)
            destinationRankIndex--;

        if (destinationRankIndex > 0)
        {
            if (sourceColCard->rank == ranks[destinationRankIndex - 1]) // Ensure the rank is descending
                return true;
            else
            {
                wcout << L"Error: The " << sourceColCard->getCard() << L" does not obey descending order when inserted in " << L"c" << numToWString(destinationIndex + 1) << L"." 
                      << L"The next card can only be: " << ranks[destinationRankIndex - 1] << L" " 
                      << ((destinationColCard->suit == suits[2] || destinationColCard->suit == suits[3]) ? suits[0] : suits[2])
                      << L" or " << ranks[destinationRankIndex - 1] << L" " 
                      << ((destinationColCard->suit == suits[2] || destinationColCard->suit == suits[3]) ? suits[1] : suits[3]) << endl;
                return false;
            }
        }
        else
        {
            wcout << "Error: No card can be placed under an Ace (the lowest rank)" << endl;
            return false;
        }
    }
}

Tableau::TableauCard* Tableau::getTableauHead() const
{
    return tableauHead;
}

Tableau::~Tableau()
{
    Tableau::TableauCard* forward = tableauHead;
    Tableau::TableauCard* downward = tableauHead->down;

    while(forward)
    {
        while(downward)
        {
            Tableau::TableauCard* temp = downward;
            downward = downward->down;
            delete temp;
        }
        Tableau::TableauCard* temp = forward;
        forward = forward->next();
        delete temp;
        if(forward != nullptr) // Because on last node it give seg fault if not taken in consideration
            downward = forward->down;
    }
    tableauHead = nullptr;
    tableauTail = nullptr;
}
