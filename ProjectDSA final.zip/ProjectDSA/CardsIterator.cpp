#include "header.h"

CardsIterator::CardsIterator() : current(nullptr)
{ }

CardsIterator::CardsIterator(Card* ptr) : current(ptr)
{ }

CardsIterator::CardsIterator(CardsIterator&& other) noexcept : current(other.current)
{
    other.current = nullptr;
}

CardsIterator& CardsIterator::operator = (CardsIterator&& other) noexcept
{
    if(this != &other)
    {
        current = other.current;
        other.current = nullptr;
    }
    return *this;
}

CardsIterator::CardsIterator(const CardsIterator& other) : current(other.current) 
{ }

CardsIterator& CardsIterator::operator = (const CardsIterator& other) 
{
    if (this != &other) {
        current = other.current; // Copy the pointer
    }
    return *this;
}

Card& CardsIterator::operator * ()
{
    if(current != nullptr)
        return *current;
    else
        throw runtime_error("Dereferencing a nullptr in CardsIterator");
}

Card* CardsIterator::operator -> ()
{
    return current;
}

// Pre-increment
CardsIterator& CardsIterator::operator ++ () 
{
    if(current != nullptr)
        current = current->next;
    return *this;
}

// Post-increment operator
CardsIterator CardsIterator::operator ++ (int) 
{ 
    CardsIterator temp = *this; 
    if (current != nullptr)
        current = current->next; 
    return temp; 
}

