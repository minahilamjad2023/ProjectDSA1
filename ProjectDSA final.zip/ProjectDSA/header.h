#ifndef HEADER_H
#define HEADER_H

#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <utility>
#include <stdexcept>
#include <iomanip>
#include <vector>
#include <algorithm>
#include <stack>

using namespace std;

extern int TOTAL_CARDS;
extern int RANKS;
extern int SUITS;
extern int No_OF_COLUMNS;

class Card
{
    public:
        wstring rank;
        wstring suit;
        Card* next;
        Card* prev;
    public:
        Card(const wstring& = L"", const wstring& = L"", Card* = nullptr, Card* = nullptr);
        virtual ~Card() = default;
        // Prevent copying instead using move sementics
        Card(const Card&) = delete;
        Card& operator = (const Card&) = delete;
        // Resourse transfer using move sementics
        Card(Card&& other) noexcept;
        Card& operator = (Card&& other) noexcept;
        virtual wstring getCard() const;
        friend class Deck;
        friend class CardsIterator;
};

class CardsIterator
{
    private:
        Card* current;
    public:
        CardsIterator();
        CardsIterator(Card*);
        CardsIterator(CardsIterator&&) noexcept;
        CardsIterator& operator = (CardsIterator&&) noexcept;
        CardsIterator(const CardsIterator&);
        CardsIterator& operator = (const CardsIterator&);
        Card& operator*();
        Card* operator->();
        CardsIterator& operator++(); // Pre-increment
        CardsIterator operator++(int); // Post-increment
};

class Deck
{
    private:
        int cards;
        Card* deckHead;
        Card* deckTail;
        wstring ranks[13] = {L"A", L"2", L"3", L"4", L"5", L"6", L"7", L"8", L"9", L"10", L"J", L"Q", L"K"};
        wstring suits[4] = {L"\u2665", L"\u2666", L"\u2663", L"\u2660"}; // {Heart, Diamond, Clubs Spade}
    public: 
        Deck();
        Deck(const Deck&);
        Deck& operator = (const Deck&);
        Deck(Deck&&) noexcept;
        Deck& operator = (Deck&&) noexcept;
        ~Deck();
        void initializeDeck();
        void deleteDeck();
        void shuffleDeck();
        void printDeck() const;
        Card* getCardAtIndex(int index) const;
        CardsIterator begin();
        CardsIterator end();
        Card deleteAtTail();
        void insertAtTail(Card&&);
        bool isEmpty() const;
        int length() const;
        wstring peek() const;
};

class Tableau
{
    public:
        class TableauCard : public Card
        {
            public:
                int noOfCards;
                int noOfVisibleCards;
                TableauCard* up;
                TableauCard* down;
                TableauCard(int = 0, int = 1, const wstring& = L"", const wstring& = L"", Card* = nullptr, Card* = nullptr);
                TableauCard(const TableauCard&) = delete;
                TableauCard& operator = (const TableauCard&) = delete;
                TableauCard(TableauCard&& other) noexcept;
                TableauCard& operator = (TableauCard&& other) noexcept;
                TableauCard(Card&& other) noexcept;
                TableauCard*& next();
                TableauCard*& prev();

                wstring getCard() const;
        };
        TableauCard *tableauHead;
        TableauCard *tableauTail;
        wstring ranks[13] = {L"A", L"2", L"3", L"4", L"5", L"6", L"7", L"8", L"9", L"10", L"J", L"Q", L"K"};
        wstring suits[4] = {L"\u2665", L"\u2666", L"\u2663", L"\u2660"}; // {Heart, Diamond, Clubs Spade}
    public:
        Tableau();
        Tableau(const Tableau&) = delete;
        Tableau& operator = (const Tableau&) = delete;
        void push(const int, Card&&);
        Card pop(const int);
        int size(const int) const;
        wstring peek(const int) const;
        void moveCardsWithinTableau(const int, const int, const int);
        bool checkCard(const int, wstring) const;
        bool checkCardWithin(const int, const int, const int) const;
        TableauCard* getTableauHead() const;
        ~Tableau();
        friend class StockPile;
};

class Stack
{
    private:
        Deck stack;
    public:
        Stack();
        // Move Sementics
        Stack(Stack&&) noexcept;
        Stack& operator = (Stack&&) noexcept;
        // Preventing Copying
        Stack(const Stack&) = delete;
        Stack& operator = (const Stack&) = delete;
        // Functions
        void initializeStack();
        void shuffleStack();
        // Push and Pop functions in stack
        Card pop();
        void push(Card&&);
        wstring peek() const;
        void printStack() const;
        int size() const;
        bool isEmpty() const;
        void deleteStack();
};

class WastePile
{
    private:
        Stack wastePileStack;
    public:
        WastePile();
        WastePile(WastePile&&) noexcept;
        WastePile& operator = (WastePile&&) noexcept;
        Card pop();
        void push(Card&&);
        wstring peek() const;
        int size() const;
        bool isEmpty() const;
        friend class StockPile;
};

class StockPile
{
    private:
        Stack stockPileStack;
        bool cardsGivenToTableau;
    public:
        StockPile();
        // Move Sementics for StockPile class
        StockPile(StockPile&&) noexcept;
        StockPile& operator = (StockPile&&) noexcept;
        // Move Sementics for Waste Pile class
        StockPile(WastePile&&) noexcept;
        StockPile& operator = (WastePile&&) noexcept;
        // Deleting Copy Sementics
        StockPile(const StockPile&) = delete;
        StockPile& operator = (StockPile&) = delete;
        void distributeCards(Tableau&);
        // Push and pop for StockPile
        Card pop();
        void push(Card&&);
        wstring peek() const;
        int size() const;
        bool isEmpty() const;
        friend class WastePile;
};

class FoundationPile
{
    private:
        Stack foundations[4];
        wstring ranks[13] = {L"A", L"2", L"3", L"4", L"5", L"6", L"7", L"8", L"9", L"10", L"J", L"Q", L"K"};
        wstring suits[4] = {L"\u2665", L"\u2666", L"\u2663", L"\u2660"}; // {Heart, Diamond, Clubs, Spade}
    public:
        FoundationPile();
        // Move sementics
        FoundationPile(FoundationPile&&) noexcept;
        FoundationPile& operator = (FoundationPile&&) noexcept;
        // Push and Pop functions
        void push(const int, Card&&);
        Card pop(const int);
        wstring peek(const int) const;
        int size(const int) const;
        // Cheak functions
        bool isEmpty(const int) const;
        bool checkSize(const int) const;
        bool checkCard(const int, wstring) const;

};

class Command
{
    private:
        stack<string> commandsStack;
    public:
        Command();
        Command(const string&);
        string trim(string&);
        // Validation of Command
        bool validateCommand(string&, const StockPile&, const WastePile&, const FoundationPile&, const Tableau&);
        // Push and Pop on command stack
        void push(const string&);
        // Implement Command
        void implementCommand(string&, StockPile&, WastePile&, FoundationPile&, Tableau&, bool reverse);
};

#endif // HEADER_H