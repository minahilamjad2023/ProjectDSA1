#include "header.h"

Stack::Stack() : stack(Deck())
{ }

Stack::Stack(Stack&& other) noexcept : stack(move(other.stack))
{ }

Stack& Stack::operator = (Stack&& other) noexcept
{
    if(!stack.isEmpty())
        stack.deleteDeck();
    stack = move(other.stack);
    return *this;
}

void Stack::initializeStack()
{
    stack.initializeDeck();
}

void Stack::shuffleStack()
{
    if(!stack.isEmpty())
    {
        stack.shuffleDeck();
    }
    else
        throw runtime_error("Empty stock pile cannot be shuffled");
}

Card Stack::pop()
{
    if(!stack.isEmpty())
        return stack.deleteAtTail();
    else
        throw runtime_error("Cannot pop from an empty stock pile");
}

// After this the card that was being added to Stack is being left behing in invalid state
void Stack::push(Card&& other)
{
    stack.insertAtTail(move(other));
}

void Stack::printStack() const
{
    stack.printDeck();
}

int Stack::size() const
{
    return stack.length();
}

bool Stack::isEmpty() const
{
    return stack.isEmpty();
}

void Stack::deleteStack()
{
    if(stack.length() == 0)
        stack.deleteDeck();
    else
        throw runtime_error("Cannot delete en empty Stack.");
}

wstring Stack::peek() const
{
    if(!isEmpty())
        return stack.peek();
    else
        throw runtime_error("Cannot peek on an Empty Stack");
}