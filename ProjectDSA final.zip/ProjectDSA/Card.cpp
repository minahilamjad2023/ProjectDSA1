#include "header.h"

// Constructor to initialize a Card object with rank, suit, next, and previous pointers
Card::Card(const wstring& rank, const wstring& suit, Card* next, Card* prev) : rank(rank), suit(suit), next(next), prev(prev)
{ }

// Move constructor to transfer ownership of a Card object
Card::Card(Card&& other) noexcept
{
    rank = move(other.rank);
    suit = move(other.suit);
    next = nullptr;
    prev = nullptr;
    other.next = nullptr;
    other.prev = nullptr;
}

// Move assignment operator to transfer ownership of a Card object
Card& Card::operator = (Card&& other) noexcept
{
    if(this != &other)
    {
        rank = move(other.rank);
        suit = move(other.suit);
        next = nullptr;
        prev = nullptr;
        other.next = nullptr;
        other.prev = nullptr;
    }
    return *this;
}

// Function to get the card's rank and suit as a string
wstring Card::getCard() const
{
    return rank + L" " + suit;
}