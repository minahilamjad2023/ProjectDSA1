#include "header.h"

// Default Constructor
WastePile::WastePile() : wastePileStack(Stack())
{ }

// Move Constructor For WastePile class
WastePile::WastePile(WastePile&& other) noexcept : wastePileStack(Stack(move(other.wastePileStack)))
{ }

// Move assignment Operator for WastePile class
WastePile& WastePile::operator = (WastePile&& other) noexcept
{
    wastePileStack = (move(other.wastePileStack));
    return *this;
}

Card WastePile::pop()
{
    if(!wastePileStack.isEmpty())
        return wastePileStack.pop();
    else
        throw runtime_error("Cannot pop from an empty stock pile");
}

void WastePile::push(Card&& other)
{
    wastePileStack.push(move(other));
}

int WastePile::size() const
{
    return wastePileStack.size();
}

bool WastePile::isEmpty() const
{
    return wastePileStack.isEmpty();
}

wstring WastePile::peek() const
{
    if(!wastePileStack.isEmpty())
        return wastePileStack.peek();
    else
        throw runtime_error("Cannot peek on a Empty Waste Pile");
}