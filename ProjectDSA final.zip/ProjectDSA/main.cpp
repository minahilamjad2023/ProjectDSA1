#include "header.h"
#include <fcntl.h>
#include <io.h>
#include <stdio.h>
#include <string>
#include <sstream>

int TOTAL_CARDS = 52;
int RANKS = 13;
int No_OF_COLUMNS = 7;
int spacing = 15;
int SUITS = 4;

void printStarting();
void print(const StockPile&, const WastePile&, const FoundationPile&, const Tableau&);
bool checkWin(const FoundationPile&);

int main()
{
    #ifdef _WIN32
        #include <io.h>
        #include <fcntl.h>
        _setmode(_fileno(stdout), 0x20000);
    #endif

    printStarting();
    StockPile s;
    Tableau t;
    FoundationPile f;
    WastePile w;
    Command c;

    s.distributeCards(t);
    print(s, w, f, t);

    string commandGiven;
    
    while(commandGiven != "end")
    {
        wcout << "Please Enter: ";
        cin.clear();  
        cin.sync(); 
        getline(cin, commandGiven);
        if(commandGiven == "end")
            break;

        if(commandGiven != "z")
        {
            c.implementCommand(commandGiven, s, w, f, t, false);
            c.push(commandGiven);
            print(s, w, f, t);
        }
        else
        {
            c.implementCommand(commandGiven, s, w, f, t, true);
            print(s, w, f, t);
        }

        if(checkWin(f))
        {
            wcout << endl << endl << "-----------------------------------------------" << endl;
            wcout << "You Won" << endl;
            wcout << endl << endl << "-----------------------------------------------"  << endl;
            return 0;
        }
    }
    return 0;
}

void printStarting()
{
    wcout << setw(70) << L"-----------------------------" << endl;
    wcout << setw(70) << right << L"| Welcome to Solitaire Game |" << endl;
    wcout << setw(70) << L"-----------------------------" << endl;

    // Game Rules and Command Syntax
    wcout << L"Game Interface:" << endl;
    wcout << L"---------------" << endl;
    wcout << L"Following commands will be used for the game play:" << endl;
    wcout << L"• To draw a card from stockpile, use command: s" << endl;
    wcout << L"• To move a card, use command: m followed by the source, destination, and number (for number of cards)." << endl;
    wcout << L"  o For example: m c6, c1, 2 means move two cards from c6 (column 6) to c1." << endl;
    wcout << L"  o Command m w, c1, 1 means move 1 card from waste pile to c1." << endl;
    wcout << L"• To undo a move or draw operation, use command: z" << endl;
    wcout << L"• The Foundation Pile suits are placed in the following order: ♥️ (Hearts), ♦️ (Diamonds), ♣️ (Clubs), ♠️ (Spades)." << endl;

    
    wcout << L"To continue, press any character..." << endl;

    // Wait for user input
    char ch;
    cin >> ch; // Read a character from the user
    wcout << L"You pressed: " << ch << L". Let's begin the game!" << endl << endl << endl;
}


void print(const StockPile& s, const WastePile& w, const FoundationPile& f, const Tableau& t)
{
    wcout << left; // To left align
    // Print headers for the game components
    wcout << setw(spacing) << "Stock"
          << setw(2 * spacing) << "Waste"
          << setw(spacing) << "Foundation 1"
          << setw(spacing) << "Foundation 2"
          << setw(spacing) << "Foundation 3"
          << setw(spacing) << "Foundation 4" << endl;

    wcout << setw(spacing) << "[  ]"  // Stock
          << setw(2 * spacing) << (w.size() > 0 ? w.peek() : L"[  ]") // Waste
          << setw(spacing) << ((f.isEmpty(0) ? L"[  ]" : f.peek(0)))  // Foundation 1
          << setw(spacing) << ((f.isEmpty(1) ? L"[  ]" : f.peek(1)))  // Foundation 2
          << setw(spacing) << ((f.isEmpty(2) ? L"[  ]" : f.peek(2)))  // Foundation 3
          << setw(spacing) << ((f.isEmpty(3) ? L"[  ]" : f.peek(3)))  << endl; // Foundation 4

    // Helper function to convert numbers to wstring
    auto numToWString = [](int num) -> std::wstring {
        std::wstringstream wss;
        wss << num;
        return wss.str();
    };

    wcout << setw(spacing) << (L"(" + numToWString(s.size()) + L" cards)")
          << setw(2 * spacing) << (L"(" + numToWString(w.size()) + L" cards)")
          << setw(spacing) << (L"(" + numToWString(f.size(0)) + L" cards)")
          << setw(spacing) << (L"(" + numToWString(f.size(1)) + L" cards)")
          << setw(spacing) << (L"(" + numToWString(f.size(2)) + L" cards)")
          << setw(spacing) << (L"(" + numToWString(f.size(3)) + L" cards)")
          << endl << endl;
    
    // Printing Tableau
    Tableau::TableauCard* forward = t.getTableauHead();
    Tableau::TableauCard* downward = t.getTableauHead();

    // Which Column has max cards in it
    int maxColCards = 0;
    while(forward)
    {
        if(forward->noOfCards > maxColCards)
            maxColCards = forward->noOfCards;
        forward = forward->next();
    }
    
    forward = t.getTableauHead();
    wcout << setw(spacing) << left << "C1" << setw(spacing) << left << "C2" << setw(spacing) << left << "C3" << setw(spacing) << left << "C4" << setw(spacing) << left << "C5" << setw(spacing) << left << "C6" << setw(spacing) << left << "C7" << endl;
    while(forward)
    {
        wcout << setw(spacing) << left << (L"(" + numToWString(forward->noOfCards) + L" cards)");
        forward = forward->next();
    }
    wcout << endl;
    
    // Rows are printing wrt to the max cards in the col of tableau
    for(int i = 1; i <= maxColCards; i++)
    {
        forward = t.getTableauHead();
        downward = t.getTableauHead();

        for(int j = 1; j <= No_OF_COLUMNS; j++)
        {
            int k = 0;
            for(; downward != nullptr && k < i; k++)
            {
                downward = downward->down;
            }
            // K becomes i in while printing each row so when i = 1 (C1: k(1) > 1-1, C2: k(1) > 2-1, ..), i = 2 (C1: nullptr, C2: k(2) > 2-1, C3: k(2) > 3-1, ..)
            if(downward != nullptr && (k > forward->noOfCards - forward->noOfVisibleCards))
                wcout << setw(spacing) << left << downward->getCard();
            else if(downward != nullptr)
                wcout << setw(spacing) << left << "[  ]";
            else
                wcout << setw(spacing) << left << "  ";
            forward = forward->next();
            downward = forward;
        }
        wcout << endl;
    }
    wcout << "----------------------------------------------------------------------------------------------------" << endl;
    wcout << endl;
}

bool checkWin(const FoundationPile& f)
{
    // Split the card into rank and suit based on space
    for(int i = 0; i < 4; i++)
    {
        wstring peek = (f.isEmpty(i) ? L"" : f.peek(i));
        size_t spacePos = peek.find(' ');
        wstring rankCard = peek.substr(0, spacePos);
        wstring suitCard = peek.substr(spacePos + 1);
        if(!(rankCard == L"K"))
            return false;
    }
    return true;
}