#include "header.h"
#include <sstream>

// Add this helper function at the top of the file after includes
static std::wstring numToWString(int num) {
    std::wstringstream wss;
    wss << num;
    return wss.str();
}

// Default Constructor
FoundationPile::FoundationPile() 
{ }

// Move Constructor
FoundationPile::FoundationPile(FoundationPile&& other) noexcept
{
    for(int i = 0; i < 4; i++)
        foundations[i] = Stack(move(other.foundations[i]));
}

// Pushing Cards onto specific Foundation Pile
void FoundationPile::push(const int destination, Card&& card)
{
    if(destination >= 0 && destination <= 3)
        foundations[destination].push(move(card));
    else
        throw runtime_error("FoundationPile::push:There foundation number is incorrect for push");
}

// Poping Cards from specific Foundation Pile
Card FoundationPile::pop(const int source)
{
    if(source >= 0 && source <= 3)
        return foundations[source].pop();
    else
        throw runtime_error("FoundationPile::pop:There foundation number is incorrect for pop");  
}

// Peeking from specific Foundation Pile
wstring FoundationPile::peek(const int source) const 
{
    if(source >= 0 && source <= 3)
    {
        return foundations[source].peek();
    }
    else
        throw runtime_error("FoundationPile::peek:The index for peek is out of bounds");
}

// Getting size of specific Foundation Pile
int FoundationPile::size(const int source) const
{
    if(source >= 0 && source <= 3)
        return foundations[source].size();
    else
        throw runtime_error("FoundationPile::peek:The index for size is out of bounds");
}

// Checking the emptiness of specific Foundation Pile
bool FoundationPile::isEmpty(const int source) const
{
    if(source >= 0 && source <= 3)
        return foundations[source].size() == 0;
    else
        throw runtime_error("FoundationPile::isEmpty:The index for size is out of bounds");   
}

// 
bool FoundationPile::checkSize(const int sourceIndex) const
{
    if(!foundations[sourceIndex].isEmpty())
        return true;
    else
        return false;
}

bool FoundationPile::checkCard(const int foundationIndex, wstring card) const
{
    // Split the card into rank and suit based on space
    size_t spacePos = card.find(' ');
    wstring rankCard = card.substr(0, spacePos);
    wstring suitCard = card.substr(spacePos + 1);

    // Ensure foundationIndex is within bounds
    if (foundationIndex < 0 || foundationIndex >= 4) 
    {
        throw runtime_error("FoundationPile::checkCard: Index out of bound");
    }

    // Check if the suit matches the required foundation pile's suit
    if (suitCard != suits[foundationIndex]) 
    {
        wcout << "Error: The suit of the card does not match the required Foundation Pile's suit." << endl;
        wcout << "The Foundation Pile suits are placed in the following order: (Hearts), (Diamonds), (Clubs), (Spades)." << endl;
        return false;
    }

    // If the foundation pile is not empty, check the top card
    if (!foundations[foundationIndex].isEmpty()) 
    {
        wstring foundationPeekCard = foundations[foundationIndex].peek();
        spacePos = foundationPeekCard.find(' ');
        wstring rankFP = foundationPeekCard.substr(0, spacePos);
        wstring suitFP = foundationPeekCard.substr(spacePos + 1);

        // Find the rank index of the top card in the foundation pile
        int rankFPIndex = 0;
        while (rankFPIndex < 13 && ranks[rankFPIndex] != rankFP) 
        {
            ++rankFPIndex;
        }

        // Validate the rank of the new card against the top card
        if (rankFPIndex < 12) // If not the last rank (King)
        { 
            if (ranks[rankFPIndex + 1] == rankCard) 
            {
                return true; // Valid move
            } 
            else
            {
                wcout << "Error: The " << card << " card does not obey ascending order when inserted in " << L"f" << numToWString(foundationIndex + 1) << "."
                    << endl << "The card that can be pushed on are: " << ranks[rankFPIndex + 1] << L" " << suits[foundationIndex] << endl;
                return false;
            }
        } 
        else if (rankFPIndex == 12 && rankFP == ranks[12]) 
        {
            wcout << "Error: The required Foundation Pile is already full." << endl;
            return false;
        }
    } 
    else // If the foundation pile is empty, only Ace can be inserted first
    { 
        if (rankCard == ranks[0]) 
        {
            return true; // Valid move
        } 
        else 
        {
            wcout << "Error: As the required Foundation Pile is empty, only Ace can be inserted first." << endl;
            return false;
        }
    }

    return false;
}
