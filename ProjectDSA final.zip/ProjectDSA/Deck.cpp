#include "header.h"

// Default Constructor
Deck::Deck() : cards(0), deckHead(nullptr), deckTail(nullptr)
{ }

// Copy Constructor
Deck::Deck(const Deck& other)
{
    if(other.deckHead != nullptr)
    {
        Card* otherCurrent = other.deckHead;
        deckHead = new Card(otherCurrent->rank, otherCurrent->suit, nullptr, nullptr);
        otherCurrent = otherCurrent->next;
        Card* current = deckHead;
        while(otherCurrent)
        {
            Card* newCard = new Card(otherCurrent->rank, otherCurrent->suit, nullptr, nullptr);
            current->next = newCard;
            newCard->prev = current;
            current = current->next;
            otherCurrent = otherCurrent->next;
        }
        deckTail = current;
        cards = other.cards;
    }
    else
    {
        deckHead = nullptr;
        deckTail = nullptr;
        cards = 0;
    }
}

// Copy Assignemnt Operator
Deck& Deck::operator = (const Deck& other) 
{
    if(this != &other)
    {
        if(deckHead != nullptr)
            deleteDeck();
        Card* otherCurrent = other.deckHead;
        deckHead = new Card(otherCurrent->rank, otherCurrent->suit, nullptr, nullptr);
        otherCurrent = otherCurrent->next;
        Card* current = deckHead;
        while(otherCurrent)
        {
            Card* newCard = new Card(otherCurrent->rank, otherCurrent->suit, nullptr, nullptr);
            current->next = newCard;
            newCard->prev = current;
            current = current->next;
            otherCurrent = otherCurrent->next;
        }
        deckTail = current;
        cards = other.cards;     
    }
    return *this;
}
       
// Move Constructor   
Deck::Deck(Deck&& other) noexcept
{
    deckHead = other.deckHead;
    deckTail = other.deckTail;
    cards = other.cards;
    
    // Here we cannot called other.delete because as transfer of resources so this class recources will also be deleted
    other.deckHead = nullptr;
    other.deckTail = nullptr;
    other.cards = 0;
}

// Move Assignment Operator
Deck& Deck::operator = (Deck&& other) noexcept
{
    if(this != &other)
    {
        if(deckHead != nullptr)
            deleteDeck();
        deckHead = other.deckHead;
        deckTail = other.deckTail;
        cards = other.cards;

        // Here we cannot called other.delete because as transfer of resources so this class recources will also be deleted
        other.deckHead = nullptr;
        other.deckTail = nullptr;
        other.cards = 0;      
    }
    return *this;
}

// Initialize to Full Deck
void Deck::initializeDeck()
{
    if(deckHead != nullptr)
        deleteDeck();
    for(int i = 0; i < 52; i++)
    {
        insertAtTail(move(Card(ranks[i % 13], suits[i / 13])));
    }
}

// Delete all Cards in Deck
void Deck::deleteDeck()
{
    while(!isEmpty())
    {
        deleteAtTail();
    }
}

// Shuffle the Cards contained in Deck
void Deck::shuffleDeck()
{
    if(deckHead != nullptr)
    {
        srand(static_cast<unsigned>(time(0)));

        for(int i = 0; i < cards; i++)
        {
            int j = rand() % cards;

            // Get pointers to the cards at indices i and j
            Card* cardI = getCardAtIndex(i);
            Card* cardJ = getCardAtIndex(j);

            // Swapping their ranks and suits
            swap(cardI->rank, cardJ->rank);
            swap(cardI->suit, cardJ->suit);
        }
    }
    else
        throw runtime_error("An empty deck cannot be shuffled.");
}

// Used in Shuffle to get corresponding cards
Card* Deck::getCardAtIndex(int index) const
{
    Card* current = deckHead;
    while(current && index > 0)
    {
        index--;
        current = current->next;
    }
    return current;
}

// Use for debugging
void Deck::printDeck() const
{
    Card* current = deckHead;
    for(int i = 0; current && i < cards; i++)
    {
        wcout << i + 1 << L" " << current->getCard() << endl;
        current = current->next;
    }   
}

// Destructor
Deck::~Deck()
{
    deleteDeck();
}

// To provide starting Iterator to Iterate
CardsIterator Deck::begin()
{
    return CardsIterator(deckHead);
}

// Ending Iterator
CardsIterator Deck::end()
{
    return CardsIterator(nullptr);
}
Card Deck::deleteAtTail() 
{
    if (deckTail != nullptr) 
    {
        Card* oldTail = deckTail;
        deckTail = deckTail->prev;

        Card temp = move(*oldTail); // Move the card data


        // Update the next pointer of the new tail
        if (deckTail != nullptr) 
        {
            deckTail->next = nullptr; // There might be a new tail
        } 
        else 
        {
            // If deckTail is now nullptr, it means the deck is empty
            deckHead = nullptr; // Ensure the head is also updated
        }

        // Free the memory of the old tail
        delete oldTail; // Free the old tail memory its resources have been transfered but it still exist in memory
        cards--; // Decrement the card count

        return temp; // Return the moved card
    } 
    else 
    {
        throw runtime_error("Cannot remove from tail from an empty deck");
    }
}

void Deck::insertAtTail(Card&& other)
{
    Card* newCard = new Card(move(other)); // For Document purpose so that user knows this is also moved slthough it works wihtout move as it is already an rvalue ref
    if(deckHead == nullptr)
    {
        deckHead = newCard;
        deckTail = newCard;
        deckHead->prev = nullptr;
        deckHead->next = nullptr;
    }
    else
    {
        deckTail->next = newCard;
        newCard->prev = deckTail;
        deckTail = newCard;
        deckTail->next = nullptr;
    }
    cards++;
}

bool Deck::isEmpty() const
{
    return cards == 0;
}

int Deck::length() const
{
    return cards;
}

wstring Deck::peek() const
{
    if(!isEmpty())
        return deckTail->getCard();
    else
        throw runtime_error("Cannot peek on an Empty Deck");
}

